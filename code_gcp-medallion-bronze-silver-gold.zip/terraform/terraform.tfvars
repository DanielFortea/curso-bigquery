project_id  = "curso-gcp-medallion"
region      = "us-central1"
bq_location = "US"
github_repository = "edumartinez99/curso-gcp-medallion"